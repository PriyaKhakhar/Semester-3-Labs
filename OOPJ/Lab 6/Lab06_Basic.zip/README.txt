Lab 6 - Basic Java Programs
Simple/viva-friendly source files.
Questions are kept in source comments as provided in the lab plan.
